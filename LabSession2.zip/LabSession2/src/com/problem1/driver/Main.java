package com.problem1.driver;


import java.io.IOException;
import java.util.Scanner;

import com.problem1.service.TransactionService;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		
		//BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the size of transaction array");
		int size = sc.nextInt();
		
		int array[]= new int[size];
		
		System.out.println("Enter the values of array");
		
		for(int i=0;i<size;i++)
		{
			array[i]=sc.nextInt();
			
		}
		
		TransactionService transactionService = new TransactionService();
		
		System.out.println("Enter the total no of targets that needs to be achieved");
		int totalTarget = sc.nextInt();
		
		for(int i=0;i<totalTarget;i++)
		{
			System.out.println("Enter the value of target");
			int valueTarget = sc.nextInt();
			int noOfTxn = transactionService.getNumberOfTransactions(array,valueTarget);
			if(noOfTxn<array.length)
			{
				System.out.println("Target achieved after "+noOfTxn+" transactions");
			}
			else
			{
				System.out.println("Given target is not achieved");
			}
		}
		sc.close();

	}

}
